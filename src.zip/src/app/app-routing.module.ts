import { Component, NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AdmissionComponent } from './admission/admission.component';
import { AttendenceComponent } from './attendence/attendence.component';
import { ContactUsComponent } from './contactUs/contactUs.component';
import { DepartmentComponent } from './department/department.component';
import { FooterComponent } from './footer/footer.component';
import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { MenuComponent } from './menu/menu.component';
import { PlacementComponent } from './placement/placement.component';
import { RegisterComponent } from './register/register.component';
import { StudentpageManuComponent } from './StudentpageManu/StudentpageManu.component';

const routes: Routes = [
  {
    path:'',
    redirectTo:'/home',
    pathMatch:'full'
  },
  {
  path:'home',
  component:HomeComponent
},
{
  path:'department',
  component:DepartmentComponent
},
{
  path:'admission',
  component:AdmissionComponent
},
{
  path:'placement',
  component:PlacementComponent
},
{
  path:'contact',
  component:ContactUsComponent
},
{
  path:'menu',
  component:MenuComponent
},
{
  path:"",
  component:HomeComponent
},
{
  path:'footer',
  component:FooterComponent
},
{
  path:'login',
  component:LoginComponent
},
{
  path:'register',
  component:RegisterComponent
},
{
  path:'StudentpageManu',
  component:StudentpageManuComponent
},
{
  path:'attendence',
  component:AttendenceComponent
},
];


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
