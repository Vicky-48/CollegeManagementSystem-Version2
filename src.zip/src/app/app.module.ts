import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeComponent } from './home/home.component';
import { PlacementComponent } from './placement/placement.component';
import { ContactUsComponent } from './contactUs/contactUs.component';
import { MenuComponent } from './menu/menu.component';
import { DepartmentComponent } from './department/department.component';
import { AdmissionComponent } from './admission/admission.component';
import { FooterComponent } from './footer/footer.component';
import { RegisterComponent } from './register/register.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { LoginComponent } from './login/login.component';
import { StudentpageManuComponent } from './StudentpageManu/StudentpageManu.component';
import { AttendenceComponent } from './attendence/attendence.component';


@NgModule({
  declarations: [		
    AppComponent,
    AdmissionComponent,
    ContactUsComponent,
    DepartmentComponent,
    FooterComponent,
    HomeComponent,
    MenuComponent,
    PlacementComponent,
    RegisterComponent,
    LoginComponent,
      StudentpageManuComponent,
      AttendenceComponent
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
