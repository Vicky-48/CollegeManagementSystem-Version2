import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  constructor(
    private fb:FormBuilder, private http:HttpClient, private route:Router
  ) {}
  formLogin=this.fb.group({
    email1:[,Validators.required],
    password1:[,Validators.required],
  })
error:boolean=false;
  loginForm(){
this.user();
this.admin();
if(this.error){
  alert("ERROR")
}

  }

user()
  {
    this.http.get<any>('http://localhost:3000/users').subscribe((users) => {
        const user = users.find((u: any) => u.email === this.formLogin.value.email1 && u.passwords === this.formLogin.value.password1
        );
        if (user) {
          alert('login Sucessfully');
          this.formLogin.reset();
          this.route.navigate(['/StudentpageManu']);
        }
        else{
          this.error=true
        }
      })
    }
    admin()
    {
    this.http.get<any>('http://localhost:3000/admin').subscribe((users) => {
        const user = users.find((u: any) => u.Aname === this.formLogin.value.email1 && u.Apassword === this.formLogin.value.password1
        );
        if (user) {
          alert('login Sucessfully');
          this.formLogin.reset();
          this.route.navigate(['/placement']);
        }
        else{
          this.error=true
        }
      })
    }

  ngOnInit() {
  }

}
