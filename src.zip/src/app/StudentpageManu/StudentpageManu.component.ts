import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-StudentpageManu',
  templateUrl: './StudentpageManu.component.html',
  styleUrls: ['./StudentpageManu.component.css']
})
export class StudentpageManuComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
